import asyncio
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path

import httpx
from jose import jwt

from controlbox.config.settings import Settings
from controlbox.modules.supabase.domain.entities import (
    RlsPolicyAction,
    SupabaseBucket,
    SupabaseProject,
    SupabaseRealtimeChannel,
    SupabaseRlsPolicy,
)


@dataclass(frozen=True)
class SupabaseConnection:
    host: str
    port: int
    admin_user: str
    admin_password: str


class SupabaseProvisioner:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._conn = SupabaseConnection(
            host=settings.supabase_db_host,
            port=settings.supabase_db_port,
            admin_user=settings.supabase_db_admin_user,
            admin_password=settings.supabase_db_admin_password,
        )

    def generate_password(self) -> str:
        return secrets.token_urlsafe(24)

    def generate_keys(self, project_ref: str, tenant_id: str) -> tuple[str, str]:
        now = int(time.time())
        exp = now + 60 * 60 * 24 * 365 * 10
        base_claims = {
            "iss": "supabase",
            "iat": now,
            "exp": exp,
            "ref": project_ref,
            "tenant_id": tenant_id,
        }
        anon = jwt.encode(
            {**base_claims, "role": "anon"},
            self._settings.supabase_jwt_secret,
            algorithm="HS256",
        )
        service = jwt.encode(
            {**base_claims, "role": "service_role"},
            self._settings.supabase_jwt_secret,
            algorithm="HS256",
        )
        return anon, service

    def _quote_ident(self, name: str) -> str:
        return f'"{name.replace(chr(34), chr(34) + chr(34))}"'

    def _quote_literal(self, value: str) -> str:
        return "'" + value.replace("'", "''") + "'"

    async def _grant_admin_membership(self, role_name: str) -> None:
        await self._execute(
            f"GRANT {self._quote_ident(role_name)} TO {self._quote_ident(self._conn.admin_user)}",
        )

    async def _revoke_admin_membership(self, role_name: str) -> None:
        await self._execute(
            f"REVOKE {self._quote_ident(role_name)} FROM {self._quote_ident(self._conn.admin_user)}",
        )

    async def provision_project(
        self,
        project: SupabaseProject,
        database_password: str,
    ) -> None:
        db_name = self._quote_ident(project.database_name)
        db_user = self._quote_ident(project.database_user)
        password = self._quote_literal(database_password)

        await self._execute(f"CREATE DATABASE {db_name} ENCODING 'UTF8'")
        await self._execute(
            f"CREATE USER {db_user} WITH PASSWORD {password} CONNECTION LIMIT 50",
        )
        await self._grant_admin_membership(project.database_user)
        try:
            await self._execute(f"GRANT ALL PRIVILEGES ON DATABASE {db_name} TO {db_user}")
            await self._execute_on_db(
                project.database_name,
                f"GRANT ALL ON SCHEMA public TO {db_user}",
            )
            await self._execute_on_db(
                project.database_name,
                f"ALTER SCHEMA public OWNER TO {db_user}",
            )
            await self._execute_on_db(
                project.database_name,
                f"ALTER DEFAULT PRIVILEGES FOR ROLE {db_user} IN SCHEMA public "
                f"GRANT ALL ON TABLES TO {db_user}",
            )
            await self._execute_on_db(
                project.database_name,
                f"ALTER DEFAULT PRIVILEGES FOR ROLE {db_user} IN SCHEMA public "
                f"GRANT ALL ON SEQUENCES TO {db_user}",
            )
            await self._execute_on_db(
                project.database_name,
                'CREATE EXTENSION IF NOT EXISTS "uuid-ossp"',
            )
            await self._execute_on_db(
                project.database_name,
                "CREATE EXTENSION IF NOT EXISTS pgcrypto",
            )
            await self._execute(f"ALTER DATABASE {db_name} OWNER TO {db_user}")
        finally:
            await self._revoke_admin_membership(project.database_user)

    async def create_schema(self, project: SupabaseProject, schema_name: str) -> None:
        db_user = self._quote_ident(project.database_user)
        schema = self._quote_ident(schema_name)
        await self._grant_admin_membership(project.database_user)
        try:
            await self._execute_on_db(
                project.database_name,
                f"CREATE SCHEMA IF NOT EXISTS {schema} AUTHORIZATION {db_user}",
            )
        finally:
            await self._revoke_admin_membership(project.database_user)

    async def drop_schema(self, project: SupabaseProject, schema_name: str) -> None:
        await self._execute_on_db(
            project.database_name,
            f'DROP SCHEMA IF EXISTS "{schema_name}" CASCADE',
        )

    async def apply_rls_policy(self, project: SupabaseProject, policy: SupabaseRlsPolicy) -> None:
        table = f'"{policy.schema_name}"."{policy.table_name}"'
        policy_name = f"cb_{policy.name}"[:63]
        await self._execute_on_db(project.database_name, f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        await self._execute_on_db(
            project.database_name,
            f'DROP POLICY IF EXISTS "{policy_name}" ON {table}',
        )
        action = policy.action.value if policy.action != RlsPolicyAction.ALL else "ALL"
        check_clause = ""
        if policy.check_expression:
            check_clause = f" WITH CHECK ({policy.check_expression})"
        await self._execute_on_db(
            project.database_name,
            f'CREATE POLICY "{policy_name}" ON {table} FOR {action} TO {policy.role_name} '
            f"USING ({policy.using_expression}){check_clause}",
        )

    async def remove_rls_policy(self, project: SupabaseProject, policy: SupabaseRlsPolicy) -> None:
        table = f'"{policy.schema_name}"."{policy.table_name}"'
        policy_name = f"cb_{policy.name}"[:63]
        await self._execute_on_db(
            project.database_name,
            f'DROP POLICY IF EXISTS "{policy_name}" ON {table}',
        )

    async def setup_realtime_channel(self, project: SupabaseProject, channel: SupabaseRealtimeChannel) -> None:
        pub_name = f"cb_{project.project_ref}_{channel.name}"[:63]
        table = f'"{channel.schema_name}"."{channel.table_name}"'
        await self._execute_on_db(project.database_name, "CREATE PUBLICATION IF NOT EXISTS supabase_realtime")
        await self._execute_on_db(
            project.database_name,
            f'ALTER PUBLICATION supabase_realtime ADD TABLE {table}',
        )

    async def remove_realtime_channel(self, project: SupabaseProject, channel: SupabaseRealtimeChannel) -> None:
        table = f'"{channel.schema_name}"."{channel.table_name}"'
        await self._execute_on_db(
            project.database_name,
            f'ALTER PUBLICATION supabase_realtime DROP TABLE {table}',
        )

    async def suspend_project(self, project: SupabaseProject) -> None:
        await self._execute(
            f'ALTER USER "{project.database_user}" CONNECTION LIMIT 0',
        )
        await self._execute(
            f'REVOKE CONNECT ON DATABASE "{project.database_name}" FROM "{project.database_user}"',
        )

    async def resume_project(self, project: SupabaseProject) -> None:
        await self._execute(
            f'GRANT CONNECT ON DATABASE "{project.database_name}" TO "{project.database_user}"',
        )
        await self._execute(
            f'ALTER USER "{project.database_user}" CONNECTION LIMIT 50',
        )

    async def deprovision_project(self, project: SupabaseProject) -> None:
        db_name = self._quote_ident(project.database_name)
        db_user = self._quote_ident(project.database_user)
        await self._execute(
            f"REVOKE CONNECT ON DATABASE {db_name} FROM PUBLIC",
        )
        await self._execute(
            f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            f"WHERE datname = {self._quote_literal(project.database_name)}",
        )
        await self._execute(f"DROP DATABASE IF EXISTS {db_name}")
        await self._revoke_admin_membership(project.database_user)
        await self._execute(f"DROP USER IF EXISTS {db_user}")

    async def get_database_size_mb(self, database_name: str) -> int:
        sql = (
            f"SELECT pg_database_size('{database_name}') AS size"
        )
        result = await self._query(sql)
        for line in result.splitlines():
            if line.strip().isdigit():
                return max(1, int(line.strip()) // (1024 * 1024))
        return 0

    def _profile_enabled(self) -> bool:
        raw = ""
        env_file = Path(self._settings.platform_config_dir) / "platform.env"
        if env_file.is_file():
            for line in env_file.read_text(encoding="utf-8").splitlines():
                if line.startswith("CONTROLBOX_ENABLED_PROFILES="):
                    raw = line.split("=", 1)[1].strip().strip('"').strip("'")
                    break
        if not raw.strip():
            raw = self._settings.controlbox_enabled_profiles or ""
        profiles = {p.strip().lower() for p in raw.replace(" ", "").split(",") if p.strip()}
        return "supabase" in profiles

    async def check_connection(self) -> tuple[bool, str]:
        if not self._profile_enabled():
            return False, (
                "Supabase no está habilitado en este servidor. "
                "Abra Configuración de producción, active Supabase (requiere MinIO/Backups) "
                "y pulse Aplicar, o ejecute controlbox repair en el VPS."
            )
        try:
            await self._query("SELECT 1")
            return True, "PostgreSQL de Supabase accesible"
        except Exception as exc:
            err = str(exc).strip()
            if "could not translate host name" in err or "Name or service not known" in err:
                return False, (
                    f"El contenedor supabase-db no está en ejecución ({self._conn.host}:{self._conn.port}). "
                    "Active el perfil supabase en Configuración de producción y ejecute controlbox repair."
                )
            return False, (
                f"No se puede conectar a Supabase en {self._conn.host}:{self._conn.port}. "
                f"Ejecute controlbox repair en el VPS. ({err})"
            )

    async def _execute(self, sql: str) -> None:
        env = {"PGPASSWORD": self._conn.admin_password}
        cmd = [
            "psql",
            "-h", self._conn.host,
            "-p", str(self._conn.port),
            "-U", self._conn.admin_user,
            "-d", "postgres",
            "-c", sql,
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            env={**os.environ, **env},
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(stderr.decode())

    async def _execute_on_db(self, database_name: str, sql: str) -> None:
        env = {"PGPASSWORD": self._conn.admin_password}
        cmd = [
            "psql",
            "-h", self._conn.host,
            "-p", str(self._conn.port),
            "-U", self._conn.admin_user,
            "-d", database_name,
            "-c", sql,
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            env={**os.environ, **env},
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(stderr.decode())

    async def _query(self, sql: str) -> str:
        env = {"PGPASSWORD": self._conn.admin_password}
        cmd = [
            "psql",
            "-h", self._conn.host,
            "-p", str(self._conn.port),
            "-U", self._conn.admin_user,
            "-d", "postgres",
            "-t", "-A",
            "-c", sql,
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            env={**os.environ, **env},
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(stderr.decode())
        return stdout.decode()


class SupabaseStorageClient:
    def __init__(self, settings: Settings) -> None:
        self._base_url = settings.supabase_storage_url.rstrip("/")
        self._service_key = settings.supabase_service_key

    async def create_bucket(self, bucket: SupabaseBucket, project: SupabaseProject) -> None:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                f"{self._base_url}/bucket",
                headers={
                    "Authorization": f"Bearer {project.service_role_key}",
                    "apikey": project.service_role_key,
                    "Content-Type": "application/json",
                },
                json={
                    "id": bucket.name,
                    "name": bucket.name,
                    "public": bucket.public,
                    "file_size_limit": bucket.file_size_limit_mb * 1024 * 1024,
                },
            )
            if response.status_code not in (200, 201) and response.status_code != 409:
                raise RuntimeError(f"Storage API error: {response.text}")

    async def delete_bucket(self, bucket_name: str, project: SupabaseProject) -> None:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.delete(
                f"{self._base_url}/bucket/{bucket_name}",
                headers={
                    "Authorization": f"Bearer {project.service_role_key}",
                    "apikey": project.service_role_key,
                },
            )
            if response.status_code not in (200, 204, 404):
                raise RuntimeError(f"Storage API error: {response.text}")

    async def list_buckets(self, project: SupabaseProject) -> list[dict]:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(
                f"{self._base_url}/bucket",
                headers={
                    "Authorization": f"Bearer {project.service_role_key}",
                    "apikey": project.service_role_key,
                },
            )
            if response.status_code != 200:
                return []
            return response.json()
